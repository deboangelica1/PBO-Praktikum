/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ObjekAnonymous;

/**
 *
 * @author debo
 */
/*
Nama    : Debora Angelika Saragih
NIM     : 41425025
Prodi   : DIV TRPL
Motto   : ORAET LABORA!
*/
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

public class Main extends Application {
    public static void main(String[] args) {launch(args);}
    @Override public void start(Stage stage)
    {
        Button button = new Button("click me");
        button.setOnAction(
        event
        ->System.out.println(
        "button clicked!"));
        
        StackPane root = new StackPane(button);
        stage.setScene (new Scene(root, 300, 200));
        stage.show();
    }
}
